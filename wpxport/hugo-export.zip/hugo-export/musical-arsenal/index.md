---
title: Musical Arsenal
author: craque
type: page
date: 2010-09-18T21:03:28+00:00
draft: true
private: true

---
My instruments and electronics, and links that matter to them&#8230; still building this list very slowly with pictures to boot, but I have a lot of shit.

Behringer

  * Xenyx1622FX Mixer
  * Truth B2031 nearfield Monitors

DIY & Crafted

  * Thingamakit
  * Cookie Monster

Looping, Sampling, Delays

  * Boss PS-3 Pitch Shifter / Delay
  * Line6 DL4 Delay Modeler
  * Electrix Repeater
  * Electrix MoFX
  * DigiTech TimeMachine RDS4000