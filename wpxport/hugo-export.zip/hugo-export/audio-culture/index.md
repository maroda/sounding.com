---
title: Audio Culture
author: craque
type: page
date: 2008-07-06T23:57:58+00:00
draft: true
private: true

---
## Zines with reviews

For the most part these cover electronica or experimental music. Most of them require physical media for submission, but several give email addresses or forms for netlabel links or mp3s.

  * [Angry Ape][1]
  * [cut-up][2]
  * [de:bug][3]
  * [Dusted][4]
  * [e|I][5] has ceased operation, but still has articles online
  * [EARLabs][6]
  * [gridface][7]
  * [Grooves][8]
  * [Igloo][9] &#8211; &#8220;Abstract Electronic Music Coverage&#8221;
  * [The Milk Factory][10]
  * [Neural][11]
  * [The Silent Ballet][12]
  * [Sonic Curiosity][13]
  * [textura][14]
  * [Tokafi][15]
  * [Vital Weekly][16] &#8211; mailing list of reviews and concerts
  * [The Wire][17]
  * [XLR8R][18]

## Promoters

  * [Trash_Audio][19]

## Audio Blogs

  * [Aural Diary][20]
  * [BikeMike][21]

## Music Related Communities

  * [.microsound repository][22]
  * [Overlap][23] releases new independent digital media, produces live events, and provides you with a free blog and podcasting tools to share your work online via Creative Commons licenses.
  * [Discogs][24]
  * [eaRLaBS][25]
  * [EM411][26]
  * [LastFM][27]
  * [jamendo][28]

## Social Networks with Music

  * [Myspace][29]
  * [Virb][30]
  * [Facebook][31]

 [1]: http://angryape.com/reviews
 [2]: http://www.cut-up.com/reviews/index.php
 [3]: http://www.de-bug.de/reviews/
 [4]: http://www.dustedmagazine.com/reviews/
 [5]: http://www.ei-mag.com/verite.php
 [6]: http://earlabs.org
 [7]: http://www.gridface.com/reviews
 [8]: http://groovesmag.com/reviews.php
 [9]: http://www.igloomag.com/doc.php?task=catmenu&category=reviews
 [10]: http://www.themilkfactory.co.uk
 [11]: http://www.neural.it
 [12]: http://thesilentballet.com/dnn/
 [13]: http://www.soniccuriosity.com
 [14]: http://www.textura.org/pages/reviews.htm
 [15]: http://www.tokafi.com
 [16]: http://www.vitalweekly.net
 [17]: http://www.thewire.co.uk
 [18]: http://www.xlr8r.com/reviews
 [19]: http://trashaudio.blogspot.com/
 [20]: http://auraldiary.splinder.com/
 [21]: http://bikemike.blogr.com/
 [22]: http://www.interdisciplina.org/microsound-repository/index.php?
 [23]: http://overlap.org/
 [24]: http://discogs.com
 [25]: http://www.earlabs.org
 [26]: http://em411.com
 [27]: http://last.fm
 [28]: http://www.jamendo.com/en/
 [29]: http://myspace.com
 [30]: http://virb.com
 [31]: http://facebook.com