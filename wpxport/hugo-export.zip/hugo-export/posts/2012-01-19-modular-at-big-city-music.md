---
title: modular at Big City Music
author: craque
type: post
date: 2012-01-20T00:50:38+00:00
url: /2012/01/19/modular-at-big-city-music/
categories:
  - Uncategorized
format: image

---
[<img src="https://sounding.com/blog/wp-content/uploads/2012/01/20120119-164939.jpg" alt="20120119-164939.jpg" class="alignnone size-full" />][1]

 [1]: https://sounding.com/blog/wp-content/uploads/2012/01/20120119-164939.jpg