---
title: …iPhone, iTouch… but what about iVinyl?
author: craque
type: post
date: 2007-09-25T21:20:00+00:00
url: /2007/09/25/…iphone-itouch…-but-what-about-ivinyl/
wpo_campaignid:
  - 1
wpo_feedid:
  - 1
wpo_sourcepermalink:
  - https://sounding.com/bin/view/Sounding/BlogEntry9
categories:
  - TWiki Archive

---
Just a little comedy for the day because every day needs it (you will need a <a target="_blank" href="http://stage6.divx.com/download/">divx plugin</a> to view this, but you should get it anyway because it&#8217;s an awesome codec!)… </p> 

<center>
</center></p> 

**Tags**: <a href="https://sounding.com/bin/view/Sounding/BlogArchive?mode=tag&search=apple, vinyl" rel="tag">apple, vinyl</a></p>