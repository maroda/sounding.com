---
title: Erotus Records Kickoff Set
author: craque
type: post
date: 2008-07-29T23:34:56+00:00
url: /2008/07/29/erotus-records-kickoff-set/
categories:
  - External
tags:
  - labels
  - shows

---
Here&#8217;s a live set from the guys at <a href="http://erotus.net" target="_blank">Erotus</a> (Blamstrain&#8217;s new label) celebrating its launch, featured in the <a href="www.uudenmusiikinfestivaali.org" target="_blank"><em>Viides Uuden Musiikin Festivaali</em></a>, or &#8220;Fifth Festival for New Music&#8221;, held in Kupittaanpuisto, Turku, Finland.

<a href="Erotus_Records_-_Label_Launch_at_Festival_For_New_Music_5_-_25-07-2008.mp3" target="_blank">Download it</a> to hear **area**, **asketix**, **blamstrain**, **ercola**, and **mk10** (not necessarily in that order) throw down a continuous two and a half hour set of glitch-filled, sometimes psychedelic, always atmospheric minimal techno from 25 July in Finland.