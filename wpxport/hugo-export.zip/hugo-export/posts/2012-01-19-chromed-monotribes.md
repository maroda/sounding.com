---
title: chromed monotribes
author: craque
type: post
date: 2012-01-19T20:59:11+00:00
url: /2012/01/19/chromed-monotribes/
categories:
  - Uncategorized
format: image

---
[<img src="https://sounding.com/blog/wp-content/uploads/2012/01/20120119-125453.jpg" alt="20120119-125453.jpg" class="alignnone size-full" />][1]

 [1]: https://sounding.com/blog/wp-content/uploads/2012/01/20120119-125453.jpg