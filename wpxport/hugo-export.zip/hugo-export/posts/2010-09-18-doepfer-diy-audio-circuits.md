---
title: Doepfer DIY audio circuits
author: craque
type: post
date: 2010-09-18T20:47:34+00:00
url: /2010/09/18/doepfer-diy-audio-circuits/
categories:
  - building
  - External

---
Check out these great <a href="http://www.doepfer.de/DIY/a100_diy.htm" target="_new">DIY schematics and tutorials for audio electronics</a> published by Doepfer&#8230; found this while working on a passive mixer for Long Beach SoundWalk.