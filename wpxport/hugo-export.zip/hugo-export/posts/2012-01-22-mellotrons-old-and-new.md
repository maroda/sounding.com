---
title: mellotrons old and new
author: craque
type: post
date: 2012-01-22T23:05:44+00:00
url: /2012/01/22/mellotrons-old-and-new/
categories:
  - Uncategorized
format: image

---
[<img src="https://sounding.com/blog/wp-content/uploads/2012/01/20120122-150515.jpg" alt="20120122-150515.jpg" class="alignnone size-full" />][1]

 [1]: https://sounding.com/blog/wp-content/uploads/2012/01/20120122-150515.jpg