---
title: Fullerton Art Walk Menagerie
author: craque
type: post
date: 2012-04-09T01:00:57+00:00
url: /2012/04/08/fullerton-art-walk-menagerie/
enclosure:
  - |
    |
        http://craque.net/snd/live/craque+ta2yerface.mp3
        418375808
        audio/mpeg
        
categories:
  - Craque
  - listening
  - live
  - performance

---
Here&#8217;s my own collection of aural glass animals for you to enjoy&#8230; a [mix of groovy and beaty dreamscapes][1] (3:38 @ 256K cbr mp3), recorded live for the Fullerton Art Walk on Friday (April 6), accompanying tattoo artist Jon Kelly (known for <a href="http://oldetymetattoos.com/" target="_blank">Olde Tyme Tattoo</a>) as he applies his latest in biomechanical fashion.

=== e d  i   t ===

&#8230;by the way a vinyl mix&#8230;

&nbsp;

 [1]: http://craque.net/snd/live/craque+ta2yerface.mp3