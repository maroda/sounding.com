---
title: Updated Audio Software
author: craque
type: post
date: 2008-10-10T18:21:10+00:00
url: /2008/10/10/updated-audio-software/
categories:
  - Music Tech
tags:
  - software

---
I&#8217;ve done some updates to the <a href="https://sounding.com/blog/?page_id=89" target="_blank">Audio Software</a> page, including three new categories: &#8220;Looping and Performance&#8221;, &#8220;Free Players and Visualizers&#8221; and &#8220;Programming Languages&#8221;.