---
title: Now Playing
author: craque
type: post
date: 2012-05-29T14:57:44+00:00
url: /2012/05/29/now-playing-3/
categories:
  - listening
tags:
  - now playing

---
&#8211; Peter Dundov ::: _Ideas from the Pond_ &#8211;

&#8211; Squarepusher ::: _Ufabulum_ &#8211;

&#8211; Fluxion ::: _Traces EP 2/3_ &#8211;

&#8211; Clark ::: _Iradelphic_ &#8211;

&#8211; Actress ::: _R.I.P._ &#8211;