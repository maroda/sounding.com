---
title: Coming soon… Craque on Audiobulb
author: craque
type: post
date: 2008-12-18T02:17:53+00:00
url: /2008/12/17/coming-soon-craque-on-audiobulb/
categories:
  - Craque
  - listening
tags:
  - audiobulb
  - Craque
  - releases

---
So my new full-length album, _Supple_, will be released by <a href="http://audiobulb.com" target="_blank">Audiobulb</a> in March of 2009. Ain&#8217;t that awesome! It&#8217;s a real honor to be joining in the ranks of Autistici, HeCanJog, Ultre, Calika, and so many others.

Months have gone by (actually, no, YEARS) where I have absorbed things, seen new parts of the world, learned new techniques, sought out what&#8217;s further; and this album evolved alongside me. The entire work has grown from single tracks and loose groupings to continuity and connection through thematic reverberation, it&#8217;s been fun and full of discovery. There are parts which stand alone but don&#8217;t feel complete without the context, it&#8217;s a &#8220;large work&#8221; in every sense of the word. I even managed to squeeze a few vocal bits in there &#8211; yes! my voice! real melody!

Look out for it in March, 2009. Craque: Supple.