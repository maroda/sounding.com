---
title: played on this one with Don Buchla himself
author: craque
type: post
date: 2012-01-19T21:12:20+00:00
url: /2012/01/19/played-on-this-one-with-don-buchla-himself/
categories:
  - Uncategorized
format: image

---
[<img src="https://sounding.com/blog/wp-content/uploads/2012/01/20120119-131049.jpg" alt="20120119-131049.jpg" class="alignnone size-full" />][1]

 [1]: https://sounding.com/blog/wp-content/uploads/2012/01/20120119-131049.jpg