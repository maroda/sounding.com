---
title: futuristic devices at teenage engineering
author: craque
type: post
date: 2012-01-22T21:32:07+00:00
url: /2012/01/22/futuristic-devices-at-teenage-engineering/
categories:
  - Uncategorized
format: image

---
[<img src="https://sounding.com/blog/wp-content/uploads/2012/01/20120122-133038.jpg" alt="20120122-133038.jpg" class="alignnone size-full" />][1]

 [1]: https://sounding.com/blog/wp-content/uploads/2012/01/20120122-133038.jpg