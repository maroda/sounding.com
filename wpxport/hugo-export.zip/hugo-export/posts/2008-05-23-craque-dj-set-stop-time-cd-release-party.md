---
title: 'Craque DJ set: Stop Time CD release party'
author: craque
type: post
date: 2008-05-23T17:20:00+00:00
url: /2008/05/23/craque-dj-set-stop-time-cd-release-party/
wpo_campaignid:
  - 1
wpo_feedid:
  - 1
wpo_sourcepermalink:
  - https://sounding.com/bin/view/Sounding/BlogEntry24
enclosure:
  - |
    http://craque.net/snd/live/dj/craque-post-stop-time.mp3
    154015367
    audio/mpeg
categories:
  - TWiki Archive
tags:
  - dj
  - releases
  - shows

---
<img src="https://sounding.com/blog/wp-content/plugins/wp-o-matic/cache/6ffce_stoptime1.jpg" alt="" hspace="2" vspace="2" align="left" /> Wednesday night I played after John Harrington&#8217;s **Stop Time** for their CD release party, you can hear the 2-hour set new on <a href="http://craque.net/craque.xml" target="_blank">CraqueCast</a> or <a href="http://craque.net/snd/live/dj/craque-post-stop-time.mp3" target="_blank">download</a> the full thing directly.

I also have several <a href="http://gallery.mac.com/maroda#100016" target="_blank">pictures</a> from the gig for all to see… John moves ALL THE TIME so my little digital camera could never get a clean shot of him!

As many of you may know, I improvise all my DJ sets. So I almost never have a full set list, because I&#8217;m just going with the flow. This time I stuck to only vinyl and after recording made a point to note the songs – I may have one or two titles wrong, but here&#8217;s the setlist:

<img src="https://sounding.com/blog/wp-content/plugins/wp-o-matic/cache/6ffce_stoptime2.jpg" alt="" align="right" /> 

  * Savath + Savalas : Rolls and Waves of Ignorance
  * Mr. Scruff : Get a Move On
  * Parov Stelar : Wanna Get
  * Mr. Scruff vs. Quantic : Dub!
  * Tosca : Damentag
  * Quantic : Mishaps Happening
  * Pyokn : Ganesha
  * Peace Orchestra Reset : Raw Deal
  * Shpongle : Dorset Perception
  * Ulf Lohmann : Java
  * Flanger : Bosco&#8217;s Disposable Driver
  * Herbert : Suddenly
  * Losoul : Position
  * Amalgamation of Soundz : For Real
  * Mark Farina : Dream Machine
  * Mr. Scruff : Night Time
  * Awa Band : Bababatteur
  * Savath + Savalas : Rolls and Waves of Acknowledgement
  * Dub Taylor : Doin It
  * Rithma : Love + Music
  * Detroit Grand Pubahs : Sandwiches
  * Losoul : Overland
  * Swayzak : Form is Emptiness
  * Soundtrack : Frosty
  * Savvas Ysatis : Out to Funk
  * The Orb : Cool Harbour

This was the first live show I recorded with my new <a href="http://www.m-audio.com/products/en_us/MicroTrackII-main.html" target="_blank">M-Audio MicroTrackII</a> digital recorder… it&#8217;s like having a DAT machine without any moving parts, I love it! More on that soon&#8230;