---
title: 'Craque: “Trolling for Olives” now free download'
author: craque
type: post
date: 2008-10-03T01:54:44+00:00
url: /2008/10/02/craque-trolling-for-olives-now-free-download/
categories:
  - Craque
  - listening
tags:
  - Craque
  - releases
  - vinyl

---
In 2001 the debut 12&#8243; for Craque titled **Trolling for Olives EP** was released on <a href="http://www.discogs.com/label/Metatron+Press" target="_blank">Metatron Press</a>, and now it&#8217;s <a href="http://www.last.fm/music/Craque/Trolling+for+Olives+EP" target="_blank">available for free on last.fm</a>.

All five tracks are both streamable and downloadable, I figured I&#8217;d do them all since the original is <a href="http://www.discogs.com/sell/list?release_id=907346&ev=rp" target="_blank">still available for purchase on vinyl</a> and it&#8217;s got some dope tracks!

And I don&#8217;t know how many of my fans actually read this, but here&#8217;s the first hint that you can expect several new releases coming up in the coming months. At least three different labels will be hosting new Craque albums, so keep yer ears open!