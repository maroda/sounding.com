---
title: 'New Releases on Metatron: Joe Zitt, GWME'
author: craque
type: post
date: 2008-05-16T17:57:00+00:00
url: /2008/05/16/new-releases-on-metatron-joe-zitt-gwme/
wpo_campaignid:
  - 1
wpo_feedid:
  - 1
wpo_sourcepermalink:
  - https://sounding.com/bin/view/Sounding/BlogEntry23
categories:
  - TWiki Archive
tags:
  - netlabels
  - releases

---
Metatron Press has re-released a few more recordings on archive.org:

  * <a href="http://www.archive.org/details/joseph-zitt-collaborations" target="_blank">Collaborations</a> features Joseph Zitt&#8217;s vocals and improvisations with such musicians as <a href="http://www.discogs.com/artist/F.+Vattel+Cherry" target="_blank">F. Vattel Cherry</a>, members of <a href="http://www.last.fm/music/Gray+Code" target="_blank">Gray Code</a>, and an electronica treatment by <a href="http://www.discogs.com/artist/Craque" target="_blank">Craque</a>.

  * <a href="http://www.archive.org/details/gusty-winds-may-exist" target="_blank">Gusty Winds May Exist</a> consists of Comma member Tom Bickley on recorders and electronics with Nancy Beckman on shakuhachi. This is the first in a series of three releases by each member of Comma with hand-made packaging and album design by Joe Zitt.

  * <a href="http://www.archive.org/details/bickley-zitt-all-souls" target="_blank">All Souls</a> is a vocal improv collaboration between Joe and Tom.

Check out these rare recordings, some brilliant improvisation and collaboration here!

More Metatron Press music to come… this year is the 10th anniversary of Comma&#8217;s <a href="http://www.discogs.com/release/1030731" target="_blank">(voices)</a>, we&#8217;re working on a remix album to be released as the original is re-released in digital format on archive.org.