---
title: Internetworking
author: craque
type: post
date: 2010-11-16T17:01:41+00:00
url: /2010/11/16/internetworking/
categories:
  - Music Tech
tags:
  - community

---
A lonely computer music lab, between practice and Early Music Ensemble rehearsal. Sitting at my workstation, the phosphor lines glow back in friendship, inviting the experience. On some other terminal across an expanse of ocean lay the eyes and hands of another typist. For one reason or another, connected to the same server, our consciousness met through &#8216;talk&#8217; and the revelation hit me that this new network &#8211; in 1991 barely used by anyone but scientists and art geeks &#8211; not only passively gave us text with pictures, but also brought us together.