---
title: Networking ideas at Ramp
author: craque
type: post
date: 2007-06-28T21:07:00+00:00
url: /2007/06/28/networking-ideas-at-ramp/
wpo_campaignid:
  - 1
wpo_feedid:
  - 1
wpo_sourcepermalink:
  - https://sounding.com/bin/view/Sounding/BlogEntry5
categories:
  - TWiki Archive

---
<img src="https://sounding.com/blog/wp-content/plugins/wp-o-matic/cache/c8af0_071707_flyer_sm.jpg" align="left" border="0" /> Liz Revision, aka <a target="_blank" href="http://www.quantazelle.com">Quantazelle</a> has a new DJ residency at <a target="_blank" href="http://www.rampchicago.com">Ramp Chicago</a>, a monthly night at <a target="_blank" href="http://www.sonotheque.net">Sonotheque</a> featuring &#8220;ambient, IDM, electro and quirky, glitchy techno.&#8221; Yes, good music remains alive in Chi-town!!! </p> 

Congrats first off to <a target="_blank" href="http://lizrevision.com/">Liz</a> for the residency! If you know her music but don&#8217;t know her jewelry design, check out the goods at <a target="_blank" href="http://www.fractalspin.com">Fractalspin</a>. I like them because she does similar things with jewelry that I&#8217;ve applied so some of my <a target="_blank" href="http://www.flickr.com/gp/7551676@N05/4j0G16">sculpture</a>. </p> 

<img src="https://sounding.com/blog/wp-content/plugins/wp-o-matic/cache/c8af0_492186900_36e8e578a9_m.jpg" width="240" height="180" alt="untitled, side" align="right" border="0" /> </p> 

This is also interesting because they&#8217;re hosting a &#8216;demo swap meet&#8217; as their July installment. I think this is a great way to build community and get the people who really care about music into the same room! </p> 

The Demo Swap edition of Ramp Chicago is July 17.</p> 

**Tags**: <a href="https://sounding.com/bin/view/Sounding/BlogArchive?mode=tag&search=community, shows" rel="tag">community, shows</a></p>