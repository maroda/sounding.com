---
title: December So Far
author: craque
type: post
date: 2007-12-19T20:26:00+00:00
url: /2007/12/19/december-so-far/
wpo_campaignid:
  - 1
wpo_feedid:
  - 1
wpo_sourcepermalink:
  - https://sounding.com/bin/view/Sounding/BlogEntry15
categories:
  - TWiki Archive

---
Well I know you could just go through my Last.fm listening or whatever, but it doesn&#8217;t represent everything. So this isn&#8217;t a best-of by any stretch, just a viewfinder into what I&#8217;ve been listening to the past 3 weeks. They&#8217;re loosely grouped by category… I&#8217;ll let the reader decide how to categorize them. </p> 

<table width=100%> <tr valign=top> 

</tr> </table> 

**Tags**: <a href="https://sounding.com/bin/view/Sounding/BlogArchive?mode=tag&search=listening" rel="tag">listening</a></p>