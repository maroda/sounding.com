---
title: Pickles for Adam
author: craque
type: post
date: 2019-04-03T05:41:04+00:00
url: /2019/04/02/pickles-for-adam/
categories:
  - creativity
  - poetry

---
<div class="wp-block-image">
  <figure class="aligncenter is-resized"><img src="https://sounding.com/blog/wp-content/uploads/2019/04/pickes-for-adam-1024x854.jpg" alt="" class="wp-image-1069" width="576" height="478" /></figure>
</div>

_(on the_ <g class="gr_ gr\_77 gr-alert gr\_spell gr\_inline\_cards gr\_run\_anim ContextualSpelling ins-del multiReplace gr-progress" id="77" data-gr-id="77">_occasion_</g> _of our meeting and bridge crossing)_

<pre class="wp-block-preformatted">Vinegar still rhythm<br />   Sounds in parallel<br />      Sticks shove and<br />         Pucker.<br /><br />Twiddling stone across<br />   Steps to below regions<br />      Glass smoothly to <br />         Airwaves.<br /><br />Pentatonic organum<br />   Slides the rails aside<br />      Bringing touches on<br />         Reedlings.<br /><br />Air patterns float around<br />   Silent eyes and finds<br />      Lowly tones with<br />         Grains.<br /><br />Fermented time brings<br />   Succulent and sprung<br />      Rocks melting or<br />         Clicking.<br /><br />Repeat and distracted<br />   Silver round reflective<br />      Cover glimpse for<br />         Shakers.<br /><br />Wooden spike and leather <br />   Salient table top runner<br />      Up down swideways for<br />         Dripping.<br /><br />Finally ice in clacks <br />   Slides and carousels<br />      Rotations wax and be<br />         Poetic.<br /></pre>

(March, New York City, 2019)