---
title: DJ Vajra at Rane
author: craque
type: post
date: 2012-01-22T22:06:24+00:00
url: /2012/01/22/dj-vajra-at-rane/
categories:
  - Uncategorized
format: image

---
[<img src="https://sounding.com/blog/wp-content/uploads/2012/01/20120122-140527.jpg" alt="20120122-140527.jpg" class="alignnone size-full" />][1]

 [1]: https://sounding.com/blog/wp-content/uploads/2012/01/20120122-140527.jpg