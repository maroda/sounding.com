---
title: Miss Dinky up close
author: craque
type: post
date: 2010-10-28T05:58:50+00:00
url: /2010/10/27/miss-dinky-up-close/
categories:
  - listening

---
The call burst across as I was sitting in the datacenter.

&#8220;LIHSTEN MAHN!&#8221; came the south London accent, and I could barely discern the tones of a minimal dubby <a href="http://www.discogs.com/artist/D.Diggler" target="_blank">Dirk Diggler</a> broken beat track that I used to play all the time back on the turntables we had set up at the office&#8230; &#8220;IT&#8217;S TAHT &#8216;UN TRAC OO PLAHAY.&#8221;

When I walked into this place somewhere in SoHo, there were beams of light being reflected from everywhere around me. In every conceivable surface was plastered thousands of square mirrors, and opposite the back of the bar to the immediate left was the woman herself, <a href="http://www.discogs.com/artist/Dinky?anv=Miss+Dinky" target="_blank">Miss Dinky</a>, in the midst of another one of my favorite deep house tracks I was currently dropping back home, very likely <a href="http://www.discogs.com/artist/H%C3%A5kan+Lidbo?anv=Hakan+Lidbo" target="_blank">Hakan Lidbo</a> or something of that sort.

Naturally this wasn&#8217;t even the first time I had heard of her. In fact, living in Chicago at the time I only knew her from the select vinyl releases I picked up downstairs at Reckless Records. Working occasionally in New York meant I could be close to that part of the dance music scene at the same time, so it was an exciting event to actually run into Dinky at a bar-cum-club no larger than your average corner deli.

Recently I&#8217;ve been listening to the beats on _<a href="http://www.discogs.com/Dinky-Anemik/master/199345" target="_blank">Anemik</a>_ and they remind me of that night, grabbing the cab downtown to go where I knew one of my weirdly found idols of techno was spinning that very night in a tiny location nobody else knew about. Actually, it&#8217;s a strange coincidence this same friend of mine and I happened upon Deep Dish at a similarly tiny club in Chicago&#8230; but that&#8217;s for another blog and another glass of chartreuse.