---
title: Downtempo from the Studio
author: craque
type: post
date: 2009-03-17T21:45:15+00:00
url: /2009/03/17/downtempo-from-the-studio/
categories:
  - Craque
  - listening
tags:
  - Craque
  - improvisation
  - listening

---
I&#8217;ve set up a set in Soundcloud called &#8220;Downtempo Excursions&#8221; to post some sonic paintings created with free improvisation and minimal beats.

<div style="font-size: 11px;">
</div>

Let me know what you think! These are sort of what I&#8217;d call &#8220;composting&#8221; of materials, kaleidoscopically tapestristic, experimentally structured.