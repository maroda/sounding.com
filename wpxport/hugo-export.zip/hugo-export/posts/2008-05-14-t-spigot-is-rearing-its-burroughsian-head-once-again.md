---
title: T Spigot is rearing its burroughsian head once again
author: craque
type: post
date: 2008-05-14T18:31:00+00:00
url: /2008/05/14/t-spigot-is-rearing-its-burroughsian-head-once-again/
wpo_campaignid:
  - 1
wpo_feedid:
  - 1
wpo_sourcepermalink:
  - https://sounding.com/bin/view/Sounding/BlogEntry22
categories:
  - External
  - TWiki Archive
tags:
  - releases
  - remixes

---
My favorite live downtempo band – **T Spigot** – is back in action this year, and to start it off they&#8217;re offering the limited edition first pressing of **Experiments in the Hypnotic Production of Crime**, <a href="http://tspigot.net/?p=11" target="_blank">available through paypal</a> for a measly $5, so go get it!

The bonus is that this version of the album includes the remix of **dubnbud** which they did for the 12&#8243; release of <a href="http://www.discogs.com/release/907346" target="_blank">Trolling for Olives</a>.

The version released on <a href="http://www.discogs.com/release/171043" target="_blank">Water Music</a> didn&#8217;t include it, probably for licensing/copyright reasons imposed by Water, but it&#8217;s not exactly clear why.

At any rate, I&#8217;m glad those guys are getting the CD version out there, because it&#8217;s a great remix, and the entire album is one of my favorites of the genre.