---
title: got to try this amazing bass flute
author: craque
type: post
date: 2012-01-20T00:55:29+00:00
url: /2012/01/19/got-to-try-this-amazing-bass-flute/
categories:
  - Uncategorized
format: image

---
[<img src="https://sounding.com/blog/wp-content/uploads/2012/01/20120119-165417.jpg" alt="20120119-165417.jpg" class="alignnone size-full" />][1]

 [1]: https://sounding.com/blog/wp-content/uploads/2012/01/20120119-165417.jpg