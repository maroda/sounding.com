---
title: MakeNoise at AnalogueHaven
author: craque
type: post
date: 2012-01-19T23:43:24+00:00
url: /2012/01/19/makenoise-at-analoguehaven/
categories:
  - Uncategorized
format: image

---
[<img src="https://sounding.com/blog/wp-content/uploads/2012/01/20120119-154257.jpg" alt="20120119-154257.jpg" class="alignnone size-full" />][1]

 [1]: https://sounding.com/blog/wp-content/uploads/2012/01/20120119-154257.jpg