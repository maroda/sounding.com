---
title: Metatron Press releases Gray Code on archive.org
author: craque
type: post
date: 2008-04-17T20:02:00+00:00
url: /2008/04/17/metatron-press-releases-gray-code-on-archiveorg/
wpo_campaignid:
  - 1
wpo_feedid:
  - 1
wpo_sourcepermalink:
  - https://sounding.com/bin/view/Sounding/BlogEntry21
categories:
  - TWiki Archive
tags:
  - improvisation
  - shows

---
<a href="http://metatronpress.com" target="_blank">Metatron Press</a> (the website is slightly outdated, but not necessarily incorrect) has started a <a href="http://www.archive.org/search.php?query=collection%3Ametatron-press&sort=-publicdate" target="_blank">netlabel archive</a>, posting releases formerly available only on CDR, as well as more new stuff to come.

A quintet I played in for some time called **Gray Code** now has a live recording up, from the <a href="http://www.archive.org/details/gray-code-live-in-philadelphia-2000" target="_blank">2000 Philadelphia Fringe Festival</a>.

The name of the group is taken from the structure we often used to improvise: &#8220;In performances using the Gray Code structure for five players, we proceed through all the possible combinations of members of the group, including the silence that starts and ends the performance, five solos, ten duets, ten trios, five quartets, and the single quintet involving all the players. Each combination appears exactly once. To move from any combination to the one that follows it, a single player starts or stops performing.&#8221;