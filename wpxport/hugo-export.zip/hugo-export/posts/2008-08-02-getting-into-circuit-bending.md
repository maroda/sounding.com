---
title: Getting into Circuit-Bending?
author: craque
type: post
date: 2008-08-02T18:00:56+00:00
url: /2008/08/02/getting-into-circuit-bending/
categories:
  - External
tags:
  - circuit bending

---
<a href="http://www.anti-theory.com/soundart/" target="_blank">Sound Art at Anti-Theory.com</a> professes to be where &#8220;the art of circuit-bending was launched on the internet,&#8221; and it&#8217;s actually a nice resource for getting into avant-garde uses of musical toys.

In <a href="http://www.anti-theory.com/soundart/circuitbend/cb06.html" target="_blank">[how it works]</a> a step-by-step example shows the simple circuit-bending process, and other topics go into things like tools and equipment and advanced things about electronics.