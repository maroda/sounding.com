---
title: Modular Synth meets Wii Controller
author: craque
type: post
date: 2007-09-20T22:51:00+00:00
url: /2007/09/20/modular-synth-meets-wii-controller/
wpo_campaignid:
  - 1
wpo_feedid:
  - 1
wpo_sourcepermalink:
  - https://sounding.com/bin/view/Sounding/BlogEntry8
categories:
  - TWiki Archive

---
Here is a very well produced video showing someone who has used bluetooth and scripting to control a <a target="_blank" href="http://www.doepfer.de">Doepfer</a> modular synthesizer with a Wii controller. DOEP! </p> 

**Tags**: <a href="https://sounding.com/bin/view/Sounding/BlogArchive?mode=tag&search=video, analog, controllers" rel="tag">video, analog, controllers</a></p>