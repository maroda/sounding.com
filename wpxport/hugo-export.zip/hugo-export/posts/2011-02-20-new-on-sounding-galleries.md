---
title: 'New on sounding: galleries!'
author: craque
type: post
date: 2011-02-21T04:48:44+00:00
url: /2011/02/20/new-on-sounding-galleries/
categories:
  - building
tags:
  - photography
  - sculpture

---
I&#8217;ve decided to pull all my sculpture and art photography here to a central gallery, and have a <a href="https://sounding.com/blog/sculpture/" target="_blank">new page for my sculpture</a> that for now features most of the photos I have up on Deviant Art.

There&#8217;s a couple of new large works going, one that&#8217;s nearly complete and another just begun, photos to come soon!