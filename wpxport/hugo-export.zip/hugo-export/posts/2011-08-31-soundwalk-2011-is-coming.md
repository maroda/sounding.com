---
title: SoundWalk 2011 is coming
author: craque
type: post
date: 2011-08-31T18:01:36+00:00
url: /2011/08/31/soundwalk-2011-is-coming/
categories:
  - Craque
  - installation
  - performance
tags:
  - electro-acoustic
  - improvisation
  - shows
  - soundwalk

---
Just in case you missed it, SoundWalk Long Beach 2011 is just around the corner! Check out the newly posted set of mp3&#8217;s from last year&#8217;s event at <a href="http://craque.net" target="_blank">craque.net</a> (or [download a zip file of flac files][1] directly).

Here&#8217;s a couple of pix from last year&#8217;s event&#8230;

<figure id="attachment_444" aria-describedby="caption-attachment-444" style="width: 300px" class="wp-caption alignleft">[<img src="https://sounding.com/blog/wp-content/uploads/2011/08/craque_sw2010_playing-300x225.jpg" alt="" title="craque_sw2010_playing" width="300" height="225" class="size-medium wp-image-444" srcset="https://sounding.com/blog/wp-content/uploads/2011/08/craque_sw2010_playing-300x225.jpg 300w, https://sounding.com/blog/wp-content/uploads/2011/08/craque_sw2010_playing-1024x768.jpg 1024w" sizes="(max-width: 300px) 100vw, 300px" />][2]<figcaption id="caption-attachment-444" class="wp-caption-text">Craque performing at SoundWalk 2010 in Long Beach, CA</figcaption></figure>

<figure id="attachment_445" aria-describedby="caption-attachment-445" style="width: 225px" class="wp-caption alignright">[<img src="https://sounding.com/blog/wp-content/uploads/2011/08/craque_sw2010_dave2-225x300.jpg" alt="" title="craque_sw2010_dave2" width="225" height="300" class="size-medium wp-image-445" srcset="https://sounding.com/blog/wp-content/uploads/2011/08/craque_sw2010_dave2-225x300.jpg 225w, https://sounding.com/blog/wp-content/uploads/2011/08/craque_sw2010_dave2-768x1024.jpg 768w" sizes="(max-width: 225px) 100vw, 225px" />][3]<figcaption id="caption-attachment-445" class="wp-caption-text">Dave doubles as stagehand and soundmaker improvisor</figcaption></figure>

<figure id="attachment_446" aria-describedby="caption-attachment-446" style="width: 225px" class="wp-caption alignright">[<img src="https://sounding.com/blog/wp-content/uploads/2011/08/craque_sw2010_joined-225x300.jpg" alt="" title="craque_sw2010_joined" width="225" height="300" class="size-medium wp-image-446" srcset="https://sounding.com/blog/wp-content/uploads/2011/08/craque_sw2010_joined-225x300.jpg 225w, https://sounding.com/blog/wp-content/uploads/2011/08/craque_sw2010_joined-768x1024.jpg 768w" sizes="(max-width: 225px) 100vw, 225px" />][4]<figcaption id="caption-attachment-446" class="wp-caption-text">Later in the evening, up close with participants</figcaption></figure>

 [1]: http://craque.net/snd/swlbc/soundwalk2010_flac.zip
 [2]: https://sounding.com/blog/wp-content/uploads/2011/08/craque_sw2010_playing.jpg
 [3]: https://sounding.com/blog/wp-content/uploads/2011/08/craque_sw2010_dave2.jpg
 [4]: https://sounding.com/blog/wp-content/uploads/2011/08/craque_sw2010_joined.jpg