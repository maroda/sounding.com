---
title: Welcome to the New Sound
author: craque
type: post
date: 2008-07-06T23:31:01+00:00
url: /2008/07/06/welcome-to-the-new-sound/
categories:
  - Uncategorized

---
You may have noticed a slight change in interface on the blog here, it&#8217;s because I switched from the TWiki BlogPlugin to WordPress.

The basic reason is that although BlogPlugin is a great tool on TWiki, it&#8217;s not as fully featured as I&#8217;d like, and there is the overhead of several dependencies within TWiki. The latter reason is difficult to deal with between system crashes and other kinds of data loss, and instead of banging my head against infinite loops in perl ImageMagick, I opted to install WP.

The installation was smooth, I was able to import &#8211; with original posting dates and images! &#8211; the TWiki blog (which will be shut down posthaste, although with redirects to the correct RSS points) in its entirety.

Several twiki pages are being moved into WP pages as well.