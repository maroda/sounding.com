---
title: just some synth
author: craque
type: post
date: 2010-09-20T00:57:25+00:00
url: /2010/09/19/just-some-synth/
categories:
  - Uncategorized
tags:
  - Craque
  - DIY

---
[<img src="https://sounding.com/blog/wp-content/uploads/2010/09/p_1600_1200_B4439E7E-0F18-40F0-B1B5-E8218EBA9ABB.jpeg" alt="" class="alignnone size-full" />][1]

 [1]: https://sounding.com/blog/wp-content/uploads/2010/09/p_1600_1200_B4439E7E-0F18-40F0-B1B5-E8218EBA9ABB.jpeg