---
title: The amazing things people say to a DJ
author: craque
type: post
date: 2007-12-14T18:19:00+00:00
url: /2007/12/14/the-amazing-things-people-say-to-a-dj/
wpo_campaignid:
  - 1
wpo_feedid:
  - 1
wpo_sourcepermalink:
  - https://sounding.com/bin/view/Sounding/BlogEntry14
categories:
  - TWiki Archive

---
I don&#8217;t know whether to call this sad or a sign of the times (surely it&#8217;s both), but if nothing else it certainly makes me feel on the fringe (of what, I am not sure) moreso than ever. </p> 

Now I&#8217;ve noticed in particular that girls who come up asking if I take requests don&#8217;t listen to my answer and ask if I have this or that, or act surprised that I don&#8217;t have anything you can hear on the radio. About half the time they&#8217;ll love what I&#8217;m playing and just want to know if I have something. </p> 

Last night, a well-cleavaged young lass (do groups of friends always send the hottest chick they have at the table to request something from the DJ?) begins asking me questions about what I have to play. Not happy with my answers of &#8220;no&#8221;, and &#8220;not really&#8221; and &#8220;i don&#8217;t play pop music&#8221;, she goes on drunkenly about some REALLY GREAT CD they have in their car, but that I wouldn&#8217;t be able to play it because I had &#8220;this&#8221;. </p> 

In the most alluring way possible she leans over, cocks her head sideways, motions at the turntable playing tech-house and asks, &#8220;So what do you call this anyway?&#8221; </p> 

I respond, oh this is <a target="_blank" href="http://www.discogs.com/artist/Dub+Taylor">Dub Taylor</a>. </p> 

At first she just nods, and her blonde friend comes up. Ms. Booby Brunette says to her, &#8220;oh he can&#8217;t play our CD because he only has this Dub Taylor&#8221; while pointing at the turntable. </p> 

Incredulous, I interrupt… &#8220;no no no, this isn&#8217;t a dub taylor, this is a TURNTABLE, the MUSIC is dub taylor&#8221; </p> 

To which they both kind of giggle and flit off.</p> 

**Tags**: <a href="https://sounding.com/bin/view/Sounding/BlogArchive?mode=tag&search=dj, shows" rel="tag">dj, shows</a></p>