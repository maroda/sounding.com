---
title: New Instruments
author: craque
type: post
date: 2010-08-07T06:11:05+00:00
url: /2010/08/06/new-instruments/
categories:
  - Uncategorized
tags:
  - Craque
  - electro-acoustic
  - improvisation

---
