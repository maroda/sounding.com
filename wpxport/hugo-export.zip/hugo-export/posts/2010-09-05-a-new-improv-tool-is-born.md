---
title: A new improv tool is born
author: craque
type: post
date: 2010-09-05T20:53:37+00:00
url: /2010/09/05/a-new-improv-tool-is-born/
categories:
  - building
  - Music Tech
tags:
  - analog
  - circuitry
  - DIY
  - electronics
  - synths

---
