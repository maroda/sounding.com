---
title: Tom Erbe’s Soundhack echo/pitchshifter
author: craque
type: post
date: 2012-01-19T23:45:51+00:00
url: /2012/01/19/tom-erbes-soundhack-echopitchshifter/
categories:
  - Uncategorized
format: image

---
[<img src="https://sounding.com/blog/wp-content/uploads/2012/01/20120119-154523.jpg" alt="20120119-154523.jpg" class="alignnone size-full" />][1]

 [1]: https://sounding.com/blog/wp-content/uploads/2012/01/20120119-154523.jpg