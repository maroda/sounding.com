---
title: Circuitbend ahoy!
author: craque
type: post
date: 2007-12-09T03:26:00+00:00
url: /2007/12/08/circuitbend-ahoy/
wpo_campaignid:
  - 1
wpo_feedid:
  - 1
wpo_sourcepermalink:
  - https://sounding.com/bin/view/Sounding/BlogEntry12
categories:
  - TWiki Archive

---
I&#8217;ve now dived pretty headlong into the world of circuit bending and synthesis, and it&#8217;s hooked me. There&#8217;s a unique similarity between creating digital and analog sounds with circuits and finding sounds with microphones on objects, so I&#8217;m motivated on the ideas behind what one friend so rightly calls my &#8220;tinkering&#8221;. </p> 

What&#8217;s on the bench now is a small, multi-oscillator synth, probably with a movable filter. This will sit some how on my ever-evolving soundboard and contribute to the medium.</p> 

**Tags**: <a href="https://sounding.com/bin/view/Sounding/BlogArchive?mode=tag&search=electronics" rel="tag">electronics</a></p>