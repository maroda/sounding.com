---
title: Line6 ignoring Mac users?
author: craque
type: post
date: 2011-12-06T22:38:38+00:00
url: /2011/12/06/line6-ignoring-mac-users/
categories:
  - building
  - External

---
Someone showed me this incredibly awesome looking &#8216;DIY&#8217; pedal being done by Line6 called the <a href="http://line6.com/tcddk/" target="_blank">ToneCore DSP Developer&#8217;s Kit</a>. At first I think, aaah what a cool platform for custom DSP pedal effects, what a nice little generic pedal with cool ways of creating my own DSP configurations&#8230; you can imagine the excitement, so unfortunately diffused by this paragraph:

> Will this platform be available on the Mac?
> 
> Probably not, sorry. Freescale, the company that makes the processor, writes the development tools and as far as we know, they have no Mac development tools planned. However, it may be possible that these tools may work on an Intel-based Mac using one of the Windows emulating solutions. 

WHAT? Are you kidding me? Come on, Line6, couldn&#8217;t you have picked an actual OPEN platform like Arduino or something?