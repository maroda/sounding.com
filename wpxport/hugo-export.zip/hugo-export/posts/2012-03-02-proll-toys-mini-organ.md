---
title: Proll Toys Mini Organ
author: craque
type: post
date: 2012-03-02T20:13:00+00:00
url: /2012/03/02/proll-toys-mini-organ/
categories:
  - Uncategorized
format: image

---
[<img src="https://sounding.com/blog/wp-content/uploads/2012/03/20120302-121049.jpg" alt="20120302-121049.jpg" class="alignnone size-full" />][1]

We own this D battery operated &#8220;mini organ&#8221; that has a real blower inside and some kind of reed system&#8230; I haven&#8217;t taken it apart yet to see, and somewhat afraid of breaking it, but it works and sounds really cool!

 [1]: https://sounding.com/blog/wp-content/uploads/2012/03/20120302-121049.jpg