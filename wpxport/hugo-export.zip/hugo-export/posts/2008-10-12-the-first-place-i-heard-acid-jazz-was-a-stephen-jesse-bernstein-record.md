---
title: The First Place I Heard Acid Jazz Was A Steven Jesse Bernstein Record
author: craque
type: post
date: 2008-10-12T22:12:31+00:00
url: /2008/10/12/the-first-place-i-heard-acid-jazz-was-a-stephen-jesse-bernstein-record/
categories:
  - listening
tags:
  - spoken word

---
It&#8217;s <a href="http://www.discogs.com/release/376395" target="_blank">true</a>.