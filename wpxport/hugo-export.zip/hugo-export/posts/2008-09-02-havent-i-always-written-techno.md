---
title: haven’t i always written techno?
author: craque
type: post
date: 2008-09-02T22:11:42+00:00
url: /2008/09/02/havent-i-always-written-techno/
categories:
  - Craque

---
As the summer begins its winddown, I&#8217;ve found that I&#8217;ve been writing some interesting beat-ful music at the same time I&#8217;ve been doing completely abstract sound works. It&#8217;s fun! Each opens the doors in the other, it&#8217;s pretty interesting the way the cross-over happens, and how: even moreso these days, things are sculptural and dimensional.

For long periods of time, I feel vaguely disinterested by dance music. It&#8217;s cyclical, and it makes me wonder what my music sounds like. I&#8217;ve never had a singular influence, things always become amalgamations of my experience. I never find myself &#8220;trying to do something like so-and-so&#8221; and rarely ever have a sonic idea in my head prior to composing (it&#8217;s happened, but i&#8217;m really more of an explorer/improvisor when it comes to expressing things musically &#8211; i just allow my subconscious to do the driving), but I always do seem to have a good sense for how it all goes together.