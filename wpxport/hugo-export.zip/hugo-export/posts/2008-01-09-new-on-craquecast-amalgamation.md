---
title: 'New on CraqueCast: Amalgamation'
author: craque
type: post
date: 2008-01-09T21:17:00+00:00
url: /2008/01/09/new-on-craquecast-amalgamation/
wpo_campaignid:
  - 1
wpo_feedid:
  - 1
wpo_sourcepermalink:
  - https://sounding.com/bin/view/Sounding/BlogEntry16
enclosure:
  - |
    http://craque.net/snd/live/craque-amalgamation.mp3
    99218017
    audio/mpeg
categories:
  - TWiki Archive
tags:
  - improvisation
  - podcast
  - shows

---
Starting off the new year with an archival live show: **Amalgamation: Live at Smartbar, Chicago, 2002** is a set I did at <a href="http://smartbarchicago.com" target="_blank">SmartBar</a> in March of 2002.

This is a set where I combined many influences, methods and directions together through a wide assortment of sampled objects, guitar playing, voices, and softsynths. It&#8217;s glitchy, ambient, dark, funky, beaty and bouncy all at the same time! A really nice listen with highly contrasting sections of sound and rhythm.

<a href="http://craque.net/craque.xml" target="_blank">Subscribe</a> to the CraqueCast, or <a href="http://craque.net/snd/live/craque-amalgamation.mp3" target="_blank">download the whole show</a> to listen. You can also preview CraqueCast entries through the <a href="http://phobos.apple.com/WebObjects/MZStore.woa/wa/viewPodcast?id=78010459" target="_blank">iTunes podcast library</a>. The &#8216;bug&#8217; cover art was done by my wife, Kary.