---
title: got my NAMM pass ready…
author: craque
type: post
date: 2012-01-19T04:54:50+00:00
url: /2012/01/18/got-my-namm-pass-ready/
categories:
  - live
format: image

---
[<img class="alignnone size-full" src="https://sounding.com/blog/wp-content/uploads/2012/01/20120118-205421.jpg" alt="20120118-205421.jpg" />][1]

 [1]: https://sounding.com/blog/wp-content/uploads/2012/01/20120118-205421.jpg