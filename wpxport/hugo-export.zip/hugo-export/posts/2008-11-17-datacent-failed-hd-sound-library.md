---
title: DataCent Failed HD Sound Library
author: craque
type: post
date: 2008-11-17T21:23:19+00:00
url: /2008/11/17/datacent-failed-hd-sound-library/
categories:
  - External
  - listening
  - Music Tech
tags:
  - glitch
  - samples

---
Check this out&#8230; DataCent, a data recovery company, has started a catalog of <a href="http://datacent.com/hard_drive_sounds.php" target="_blank">common sounds heard on failing hard drives</a>, and it covers multiple vendors and situations where things can be heard going terribly wrong. Best of all, they give full permission to use the samples as long as you contact them about it.