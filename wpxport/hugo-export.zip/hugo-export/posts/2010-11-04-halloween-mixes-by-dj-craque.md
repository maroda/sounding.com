---
title: Halloween Mixes by DJ Craque
author: craque
type: post
date: 2010-11-05T06:03:43+00:00
url: /2010/11/04/halloween-mixes-by-dj-craque/
categories:
  - Craque
  - listening

---
This past weekend we presented ourselves in regalia of the **_zombie_**, partying until the early single digits at my good friend Chad&#8217;s.

I have played music at his Halloween parties for as long as I&#8217;ve lived in California, down in _Newport Beach_ as well as _Fullerton_. In 2010 the digital world has provided us with methods of being the DJ while joining the party; what follows are the set lists I prepared for the costume extravaganza at Chad&#8217;s, each on its separate ipod in different themed rooms:

<div>
  <strong><em> Weird Spooky Alien Evil Beats</em></strong>
</div>

<div>
  <strong><em><br /> </em></strong>
</div>

<div>
  Matterbuss  &#8211;  <strong>Craque</strong> &#8211;  <em>Gamma</em>
</div>

<div id="_mcePaste">
  Into The Lung  &#8211;  <strong>Fisk Industries</strong> &#8211;  <em>Analog For Architecture</em>
</div>

<div id="_mcePaste">
  Rocky (Soft)  &#8211;  <strong>Byetone</strong> &#8211;  <em>Death Of A Typographer</em>
</div>

<div id="_mcePaste">
  Hypnotic  &#8211;  <strong>T Spigot</strong> &#8211;  <em>Experiments In The Hypnotic Production Of Crime</em>
</div>

<div id="_mcePaste">
  Auto Pilot  &#8211;  <strong>Lusine</strong> &#8211;  <em>Serial Hodgepodge</em>
</div>

<div id="_mcePaste">
  Tear Strips Off  &#8211;  <strong>Tipper</strong> &#8211;  <em>Surrounded</em>
</div>

<div id="_mcePaste">
  Blood (<strong>Brassica</strong> Remix)  &#8211;  <strong>Fisk Industries</strong> &#8211;  <em>Magnetic Fisk Remixes</em>
</div>

<div id="_mcePaste">
  Woodface  &#8211;  <strong>Funckarma</strong> &#8211;  <em>Dubstoned EP</em>
</div>

<div id="_mcePaste">
  Licht  &#8211;  <strong>Craque</strong> &#8211;  <em>Density Operator</em>
</div>

<div id="_mcePaste">
  Radio Bombay  &#8211;  <strong>Hol Baumann</strong> &#8211;  <em>Human</em>
</div>

<div id="_mcePaste">
  Bell Jar  &#8211;  <strong>Craque</strong> &#8211;  <em>Jawbone</em>
</div>

<div id="_mcePaste">
  1  &#8211;  <strong>Gescom</strong> &#8211;  <em>Key Nell</em>
</div>

<div id="_mcePaste">
  Phoenix Rising  &#8211;  <strong>Bluetech</strong> &#8211;  <em>Phoenix Rising</em>
</div>

<div id="_mcePaste">
  We Are The Music Makers  &#8211;  <strong>Aphex Twin</strong> &#8211;  <em>Selected Ambient Works 85-92</em>
</div>

<div id="_mcePaste">
  Old Twisted Trees  &#8211;  <strong>KiloWatts</strong> &#8211;  <em>Ground State</em>
</div>

<div id="_mcePaste">
  When I Leave  &#8211;  <strong>Biosphere</strong> &#8211;  <em>Light</em>
</div>

<div id="_mcePaste">
  Black Sabbath  &#8211;  <strong>Venetian Snares</strong> &#8211;  <em>Sabbath Dubs</em>
</div>

<div id="_mcePaste">
  Crowley  &#8211;  <strong>Fisk Industries</strong> &#8211;  <em>Magnetism, That Electricity..</em>
</div>

<div id="_mcePaste">
  Topless  &#8211;  <strong>Craque</strong> &#8211;  <em>Supple</em>
</div>

<div id="_mcePaste">
  Interfere  &#8211;  <strong>Craque</strong> &#8211;  <em>Density Operator</em>
</div>

<div id="_mcePaste">
  Steppen  &#8211;  <strong>Landau</strong> &#8211;  <em>Thepicompromise</em>
</div>

<div id="_mcePaste">
  Break Charmer  &#8211;  <strong>Cujo</strong> &#8211;  <em>Adventures In Foam</em>
</div>

<div id="_mcePaste">
  Adrift for Days  &#8211;  <strong>Tipper</strong> &#8211;  <em>Surrounded</em>
</div>

<div id="_mcePaste">
  June Second (B)  &#8211;  <strong>Proswell</strong> &#8211;  <em>Konami</em>
</div>

<div id="_mcePaste">
  Pable Cath  &#8211;  <strong>Funckarma</strong> &#8211;  <em>Dubstoned EP</em>
</div>

<div id="_mcePaste">
  Frekvenssi  &#8211;  <strong>Ø</strong> &#8211;  <em>Oleva</em>
</div>

<div id="_mcePaste">
  Dasein  &#8211;  <strong>Loess</strong> &#8211;  <em>Wind And Water</em>
</div>

<div id="_mcePaste">
  UFO Over Trenchtown  &#8211;  <strong>Eat Static</strong> &#8211;  <em>New World Dub 01</em>
</div>

<div id="_mcePaste">
  Orgaslsp  &#8211;  <strong>Craque</strong> &#8211;  <em>Gamma</em>
</div>

<div id="_mcePaste">
  Bayreuth  &#8211;  <strong>Farben</strong> &#8211;  <em>Textstar</em>
</div>

<div id="_mcePaste">
  Spacetime Continuum, Mix 01  &#8211;  <strong>Muslimgauze</strong> &#8211;  <em>From The Edge</em>
</div>

<div id="_mcePaste">
  Dael  &#8211;  <strong>Autechre</strong> &#8211;  <em>Tri Repetae</em>
</div>

<div id="_mcePaste">
  Shoot The Moon  &#8211;  <strong>Lusine ICL</strong> &#8211;  <em>Iron City</em>
</div>

<div id="_mcePaste">
  magnesium  &#8211;  <strong>ilkae</strong> &#8211;  <em>light industry+</em>
</div>

<div id="_mcePaste">
  Tunnels OV Set (<strong>Autechre</strong> Remix)  &#8211;  <strong>The Black Dog</strong> &#8211;  <em>Final Collected Vexations</em>
</div>

<div id="_mcePaste">
  Zeal  &#8211;  <strong>Plaid</strong> &#8211;  <em>Spokes</em>
</div>

<div id="_mcePaste">
  Contain  &#8211;  <strong>Plastikman</strong> &#8211;  <em>Kompilation</em>
</div>

<div id="_mcePaste">
  Tankraken  &#8211;  <strong>Autechre</strong> &#8211;  <em>Quaristice</em>
</div>

<div id="_mcePaste">
  Organ In The Attic Sings The Blues  &#8211;  <strong>Deadbeat</strong> &#8211;  <em>Wild Life Documentaries</em>
</div>

<div id="_mcePaste">
  Slicktoo Stack  &#8211;  <strong>Craque</strong> &#8211;  <em>Metathreading</em>
</div>

<div id="_mcePaste">
  preyWithMe (<strong>b0t23</strong> mix)  &#8211;  <strong>logreybeam</strong> &#8211;  <em>rem.rem</em>
</div>

<div id="_mcePaste">
  Strawberry  &#8211;  <strong>The Bionaut</strong> &#8211;  <em>Lubricate Your Living</em> Room
</div>

<div id="_mcePaste">
  Untrue  &#8211;  <strong>Burial</strong> &#8211;  <em>Untrue</em>
</div>

<div id="_mcePaste">
  untitled (<strong>proem</strong> remix)  &#8211;  <strong>logreybeam</strong> &#8211;  <em>rem.rem</em>
</div>

<div id="_mcePaste">
  Attalal (Remixed By <strong>Biosphere</strong>)  &#8211;  <strong>Download</strong> &#8211;  <em>Biosystems: The Biosphere Remixes</em>
</div>

<div id="_mcePaste">
  Kaksoisvinokas \ Twinaskew  &#8211;  <strong>Pan Sonic</strong> &#8211;  <em>Gravitoni</em>
</div>

<div id="_mcePaste">
  Cresent Suns (w/ <strong>Slinky Wizard  Jewel</strong>)  &#8211;  <strong>binah</strong>
</div>

<div id="_mcePaste">
  Professional  &#8211;  <strong>Craque</strong> &#8211;  <em>Meat Hacker</em>
</div>

<div id="_mcePaste">
  Hours  &#8211;  <strong>Hol Baumann</strong> &#8211;  <em>Human</em>
</div>

<div id="_mcePaste">
  schoen  &#8211;  <strong>Loess</strong> &#8211;  <em>Burrows</em>
</div>

<div id="_mcePaste">
  Base Metal (Re-mix)  &#8211;  <strong>Download</strong> &#8211;  <em>Sidewinder</em>
</div>

<div id="_mcePaste">
  Lusid Crystalin  &#8211;  <strong>Craque</strong> &#8211;  <em>Supple</em>
</div>

<div id="_mcePaste">
  Electric Funeral  &#8211;  <strong>Venetian Snares</strong> &#8211;  <em>Sabbath Dubs</em>
</div>

<div id="_mcePaste">
  Mo [A.mo.re &#8211; <strong>Aeroc</strong> Mix]  &#8211;  <strong>Murcof</strong> &#8211;  <em>Utopia</em>
</div>

<div id="_mcePaste">
  Blood  &#8211;  <strong>Fisk Industries</strong> &#8211;  <em>Magnetism, That Electricity..</em>
</div>

<div id="_mcePaste">
  Lebensformen  &#8211;  <strong>Håkan Lidbo</strong> &#8211;  <em>Clicks + Cuts 4</em>
</div>

<div id="_mcePaste">
  Blackboard  &#8211;  <strong>Deru</strong> &#8211;  <em>Autonomous Addicts</em>
</div>

<div id="_mcePaste">
  Raygun  &#8211;  <strong>Zainetica</strong> &#8211;  <em>Future 740</em>
</div>

<div id="_mcePaste">
  Handcut Ice Cubes (Phil Western Silent Night Version)  &#8211;  <strong>Phil Western</strong> / <strong>Tanya Pea</strong> &#8211;  <em>Handcut Ice Cubes</em>
</div>

<div id="_mcePaste">
  S-bahn  &#8211;  <strong>Ø</strong> &#8211;  <em>Oleva</em>
</div>

<div id="_mcePaste">
  What The Night Reveals  &#8211;  <strong>Bluetech</strong> &#8211;  <em>Phoenix Rising</em>
</div>

<div id="_mcePaste">
  Clipper  &#8211;  <strong>Autechre</strong> &#8211;  <em>Tri Repetae</em>
</div>

<div id="_mcePaste">
  V-Proc  &#8211;  <strong>Autechre</strong> &#8211;  <em>Draft 7.30</em>
</div>

<div id="_mcePaste">
  Montreal  &#8211;  <strong>Autechre</strong> &#8211;  <em>Amber</em>
</div>

<div id="_mcePaste">
  beetelguise (<strong>Craque</strong> Orion Conjecture)  &#8211;  <strong>logreybeam</strong> &#8211;  <em>rem.rem</em>
</div>

<div id="_mcePaste">
  Further  &#8211;  <strong>Autechre</strong> &#8211;  <em>Amber</em>
</div>

<div id="_mcePaste">
  Garbagemx36  &#8211;  <strong>Autechre</strong> &#8211;  <em>Garbage</em>
</div>

<div id="_mcePaste">
  rew(1)  &#8211;  <strong>Autechre</strong> &#8211;  <em>Move Of Ten</em>
</div>

<div id="_mcePaste">
  Ghostwaltz on the third floor  &#8211;  <strong>Anders Ilar</strong> &#8211;  <em>Twilight Rainfalls</em>
</div>

<div id="_mcePaste">
  evac&#8217;s false premonition  &#8211;  <strong>logreybeam</strong> &#8211;  <em>rem.rem</em>
</div>

<div id="_mcePaste">
  Room 23  &#8211;  <strong>Shpongle</strong> &#8211;  <em>Tales Of The Inexpressible</em>
</div>

<div id="_mcePaste">
  DMT Original Russian Bootleg  &#8211;  <strong>Shpongle</strong> &#8211;  <em>Divine Moments of Truth EP</em>
</div>

<div id="_mcePaste">
  Shpongle Falls  &#8211;  <strong>Shpongle</strong> &#8211;  <em>Are You Shpongled</em>
</div>

<div id="_mcePaste">
  Catch 22  &#8211;  <strong>Lackluster</strong> &#8211;  <em>Container</em>
</div>

<div id="_mcePaste">
  GAMMA GOBLINS &#8216;Its Turtles All The Way Down&#8217; Mix  &#8211;  <strong>OTT</strong> &#8211;  <strong><em>Hallucinogen</em></strong><em> In Dub</em>
</div>

<div>
  <em><br /> </em>
</div>

<div>
  <em><strong> Ambient Horror and Dimensional Rifts</strong></em>
</div>

<div>
  <em><strong><br /> </strong></em>
</div>

<div>
  <div>
    Daddylonglegs  &#8211;  <strong>Higher Intelligence Agency & Biosphere</strong> &#8211;  <em>Birmingham Frequencies</em>
  </div>
  
  <div>
    ohm  &#8211;  <strong>kate carr</strong> &#8211;  <em>automatic crossing</em>
  </div>
  
  <div>
    Copper Doors (Anodized)  &#8211;  <strong>Craque</strong> &#8211;  <em>Wind Space Compost</em>
  </div>
  
  <div>
    Vainamoisen Uni \ Dream Of Vainamoinen  &#8211;  <strong>Pan Sonic</strong> &#8211;  <em>Gravitoni</em>
  </div>
  
  <div>
    my bed is my boat  &#8211;  <strong>Herzog</strong> &#8211;  <em>the autumn parade ep</em>
  </div>
  
  <div>
    ambelio  &#8211;  <strong>Arovane</strong> &#8211;  <em>Atol Scrap</em>
  </div>
  
  <div>
    For Mark Rothko  &#8211;  <strong>John Kannenberg</strong> &#8211;  <em>The Sonics of Art Spaces</em>
  </div>
  
  <div>
    First Point Of Aries  &#8211;  <strong>Deepchord Presents Echospace</strong> &#8211;  <em>The Coldest Season</em>
  </div>
  
  <div>
    Sabina Seat  &#8211;  <strong>Speedy J</strong> &#8211;  <em>A Shocking Hobby</em>
  </div>
  
  <div>
    Ready Let&#8217;s Go  &#8211;  <strong>Boards Of Canada</strong> &#8211;  <em>Geogaddi</em>
  </div>
  
  <div>
    Sleepdeprivation2  &#8211;  <strong>The Black Dog</strong> &#8211;  <em>Music For Real Airports</em>
  </div>
  
  <div>
    Notre Dame De L&#8217;oubli (For <strong>Olivier Messiaen</strong>)  &#8211;  <strong>Naked City</strong> &#8211; <em> Absinthe</em>
  </div>
  
  <div>
    Ancient Campfire  &#8211;  <strong>Biosphere</strong> &#8211;  <em>Shenzhou</em>
  </div>
  
  <div>
    Parallelogram Bin  &#8211;  <strong>Squarepusher</strong> &#8211;  <em>Music is Rotted One Note</em>
  </div>
  
  <div>
    Endless Park  &#8211;  <strong>Hol Baumann</strong> &#8211;  <em>Human</em>
  </div>
  
  <div>
    Kausaaliton  &#8211;  <strong>Ø</strong> &#8211;  <em>Oleva</em>
  </div>
  
  <div>
    Dub Stack  &#8211;  <strong>Craque</strong> &#8211;  <em>Metathreading</em>
  </div>
  
  <div>
    Ó God Protect Me  &#8211;  <strong>Ben Frost</strong> &#8211;  <em>By The Throat</em>
  </div>
  
  <div>
    Sleepdeprivation1  &#8211;  <strong>The Black Dog</strong> &#8211;  <em>Music For Real Airports</em>
  </div>
  
  <div>
    Dub For Cascadia  &#8211;  <strong>Loscil</strong> &#8211;  <em>Endless Falls</em>
  </div>
  
  <div>
    Nowhere  &#8211;  <strong>Aidan Baker</strong> &#8211;  <em>Pendulum</em>
  </div>
  
  <div>
    Leo Needs A New Pair Of Shoes  &#8211;  <strong>Ben Frost</strong> &#8211;  <em>By The Throat</em>
  </div>
  
  <div>
    Ruins  &#8211;  <strong>Axiom Ambient</strong> &#8211;  <em>Lost in the Translation</em>
  </div>
  
  <div>
    Overand  &#8211;  <strong>Autechre</strong> &#8211;  <em>Tri Repetae</em>
  </div>
  
  <div>
    Ricycle  &#8211;  <strong>Craque</strong> &#8211;  <em>Jawbone</em>
  </div>
  
  <div>
    Autsaidnait  &#8211;  <strong>Tanox</strong> &#8211;  <em>Astronomia de Balcon</em>
  </div>
  
  <div>
    Sanguineo  &#8211;  <strong>Craque / Zitt</strong> &#8211;  <em>Bookends</em>
  </div>
  
  <div>
    Aquamarine Reprise  &#8211;  <strong>The Bionaut</strong> &#8211;  <em>Lubricate Your Living Room</em>
  </div>
  
  <div>
    Canon (Part 1)  &#8211;  <strong>Bill Frisell</strong> &#8211;  <strong><em>Hal Willner</em></strong><em> Presents Weird Nightmare: Meditations On <strong>Mingus</strong></em>
  </div>
  
  <div>
    caliper remote  &#8211;  <strong>Autechre</strong> &#8211;  <em>LP5</em>
  </div>
  
  <div>
    Rarradar  &#8211;  <strong>Eye</strong> &#8211;  <em>Plays</em>
  </div>
  
  <div>
    Chain Smoking  &#8211;  <strong>Bluermutt</strong> &#8211;  <em>Uncertain Data Packed In Red Boxes</em>
  </div>
  
  <div>
    Housesonthehill  &#8211;  <strong>Biosphere</strong> &#8211;  <em>Shenzhou</em>
  </div>
  
  <div>
    Unien holvit  &#8211;  <strong>Ø</strong> &#8211;  <em>Oleva</em>
  </div>
  
  <div>
    Man From Deep River part two  &#8211;  <strong>BJ Nilsen & Stilluppsteypa</strong> &#8211;  <em>Man From Deep River</em>
  </div>
  
  <div>
    Spring/Summer  &#8211;  <strong>Blamstrain</strong> &#8211;  <em>Aurora 2</em>
  </div>
  
  <div>
    Space  &#8211;  <strong>Lackluster</strong> &#8211;  <em>Spaces</em>
  </div>
  
  <div>
    Tripside Syndicate  &#8211;  <strong>The Black Dog</strong> &#8211;  <em>Final Collected Vexations</em>
  </div>
  
  <div>
    Val De Travers  &#8211;  <strong>Naked City</strong> &#8211;  <em>Absinthe</em>
  </div>
  
  <div>
    Pathleadingtothehighgrass  &#8211;  <strong>Biosphere</strong> &#8211;  <em>Shenzhou</em>
  </div>
  
  <div>
    Meltwater  &#8211;  <strong>Higher Intelligence Agency & Biosphere</strong> &#8211;  <em>Polar Sequences</em>
  </div>
  
  <div>
    Plinth  &#8211;  <strong>The Black Dog</strong> &#8211;  <em>Final Collected Vexations</em>
  </div>
  
  <div>
    Louange Á l&#8217;Éternité de Jésus  &#8211;  <strong>Naked City</strong> &#8211;  <em>Grand Guignol</em>
  </div>
  
  <div>
    Puppetmaster  &#8211;  <strong>Ghost in the Shell</strong> &#8211;  <em>Original Soundtrack</em>
  </div>
  
  <div>
    Pan-Fried Fern  &#8211;  <strong>He Can Jog</strong> &#8211;  <em>MiddleMarch</em>
  </div>
  
  <div>
    Supple Network  &#8211;  <strong>Craque</strong> &#8211;  <em>Supple</em>
  </div>
  
  <div>
    Tlit  &#8211;  <strong>Craque</strong> &#8211;  <em>Supple</em>
  </div>
  
  <div>
    Gruven  &#8211;  <strong>Craque</strong> &#8211;  <em>Gamma</em>
  </div>
  
  <div>
    Ocean Of Emptiness  &#8211;  <strong>Deepchord Presents Echospace</strong> &#8211;  <em>The Coldest Season</em>
  </div>
  
  <div>
    Virtual Crime  &#8211;  <strong>Ghost in the Shell</strong> &#8211;  <em>Original Soundtrack</em>
  </div>
  
  <div>
    Basscadubmx  &#8211;  <strong>Autechre</strong> &#8211;  <em>Basscadet</em>
  </div>
  
  <div>
    melve  &#8211;  <strong>Autechre</strong> &#8211;  <em>LP5</em>
  </div>
  
  <div>
    Mojave  &#8211;  <strong>Ø</strong> &#8211;  <em>Oleva</em>
  </div>
  
  <div>
    Santa Ana  &#8211;  <strong>Craque</strong> &#8211;  <em>Wind Space Compost</em>
  </div>
  
  <div>
    Butterfly Bush  &#8211;  <strong>Craque</strong> &#8211;  <em>Wind Space Compost</em>
  </div>
  
  <div>
    Nightshade  &#8211;  <strong>Kilowatts</strong> &#8211;  <em>Undercurrent</em>
  </div>
  
  <div>
    Bronchusevenmx24  &#8211;  <strong>Autechre</strong> &#8211;  <em>Garbage</em>
  </div>
  
  <div>
    Inborn sea flowing  &#8211;  <strong>aless</strong> &#8211;  <em>i&#8217;mmobile</em>
  </div>
  
  <div>
    Semi-Fabulous Witches  &#8211;  <strong>Ten and Tracer</strong> &#8211;  <em>Makyo</em>
  </div>
  
  <div>
    Noise Garden Stack  &#8211;  <strong>Craque</strong> &#8211;  <em>Metathreading</em>
  </div>
  
  <div>
    SonDEre-ix  &#8211;  <strong>Autechre</strong> &#8211;  <em>Quaristice</em>
  </div>
  
  <div>
    Untitled Transient  &#8211;  <strong>Ben Frost</strong> &#8211;  <em>By The Throat</em>
  </div>
  
  <div>
    <em><br /> </em>
  </div>
  
  <div>
    <strong><em>2AM Extravaganzic Dance Hour</em></strong>
  </div>
  
  <div>
    <strong><em><br /> </em></strong>
  </div>
  
  <div>
    <div>
      You&#8217;re Only SQL (<strong>BCN</strong> Mix)  &#8211;  <strong>The Black Dog</strong> &#8211;  <em>Final Collected Vexations</em>
    </div>
    
    <div>
      Kiu_Kiu  &#8211;  <strong>Twerk</strong> &#8211;  <em>Living Vicariously Through Burnt Bread</em>
    </div>
    
    <div>
      Windowlicker (Acid Edit)  &#8211;  <strong>Aphex Twin</strong> &#8211;  <em>26 Mixes For Cash</em>
    </div>
    
    <div>
      Plasticine  &#8211;  <strong>Plastikman</strong> &#8211;  <em>Kompilation</em>
    </div>
    
    <div>
      Tophapy  &#8211;  <strong>Plaid</strong> &#8211;  <em>Booc</em>
    </div>
    
    <div>
      Ne Contsom A Coltsom  &#8211;  <strong>SCSI-9</strong> &#8211;  <em>The Line of Nine</em>
    </div>
    
    <div>
      Boogie Down Bronx (<strong>Gescom</strong> Remix)  &#8211;  <strong>Man Parrish</strong> &#8211;  <em>Mask 500</em>
    </div>
    
    <div>
      Mango Drive  &#8211;  <strong>Rhythm & Sound</strong> &#8211;  <em>Rhythm & Sound</em>
    </div>
    
    <div>
      Yellow Fingers  &#8211;  <strong>Håkan Lidbo</strong> &#8211;  <em>Meta-Matic &#8211; EP</em>
    </div>
    
    <div>
      Musical Box  &#8211;  <strong>Wagon Christ</strong> &#8211;  <em>Tally Ho!</em>
    </div>
    
    <div>
      <strong>CCTV Nation</strong> (Slam Mix)  &#8211;  <strong>The Black Dog</strong> &#8211;  <em>Final Collected Vexations</em>
    </div>
    
    <div>
      <strong>Skinclock</strong> (Silicone Soul Mix)  &#8211;  <strong>The Black Dog</strong> &#8211;  <em>Final Collected Vexations</em>
    </div>
    
    <div>
      808303  &#8211;  <strong>Richard Devine</strong> &#8211;  <em>Autonomous Addicts</em>
    </div>
    
    <div>
      Doubledip uuh&#8230;  &#8211;  <strong>Pantytec</strong> &#8211;  <em>Pony Slaystation</em>
    </div>
    
    <div>
      minreal  &#8211;  <strong>Craque</strong> &#8211;  <em>Hpynagoiga</em>
    </div>
    
    <div>
      Tango Acido  &#8211;  <strong>Losoul</strong> &#8211;  <em>Getting Even</em>
    </div>
    
    <div>
      Roots And Wire  &#8211;  <strong>Deadbeat</strong> &#8211;  <em>Roots and Wire</em>
    </div>
    
    <div>
      Seventy Four  &#8211;  <strong>Martyn</strong> &#8211;  <em>Great Lengths</em>
    </div>
    
    <div>
      Vletrmx  &#8211;  <strong>Autechre</strong> &#8211;  <em>Warp 10+3 Remixes</em>
    </div>
    
    <div>
      Out To Funk  &#8211;  <strong>Savvas Ysatis</strong> &#8211;  <em>Select</em>
    </div>
    
    <div>
      Chrysanthemum  &#8211;  <strong>Download</strong> &#8211;  <em>Effector</em>
    </div>
    
    <div>
      Breed  &#8211;  <strong>L&#8217;Usine</strong> &#8211;  <em>Autonomous Addicts</em>
    </div>
    
    <div>
      Raggafuzzer  &#8211;  <strong>Håkan Lidbo</strong> &#8211;  <em>Sound Molecules</em>
    </div>
    
    <div>
      Windowlicker  &#8211;  <strong>Aphex Twin</strong> &#8211;  <em>Warp20</em>
    </div>
    
    <div>
      squance  &#8211;  <strong>Plaid</strong> &#8211;  <em>Double Figure</em>
    </div>
    
    <div>
      Near Dark  &#8211;  <strong>Burial</strong> &#8211;  <em>Untrue</em>
    </div>
    
    <div>
      Toooly Hooof  &#8211;  <strong>Download</strong> &#8211;  <em>III</em>
    </div>
    
    <div>
      seeing but not seen  &#8211;  <strong>Phil Western and Tim Hill</strong> &#8211;  <em>Dark Features</em>
    </div>
    
    <div>
      Sex Deluxe  &#8211;  <strong>Håkan Lidbo</strong> &#8211;  <em>Sound Molecules</em>
    </div>
    
    <div>
      The Grid  &#8211;  <strong>Peverelist</strong> &#8211;  <em>Round Black Ghosts</em>
    </div>
    
    <div>
      Trouser Mouse  &#8211;  <strong>Blamstrain</strong> &#8211;  <em>Exosphere</em>
    </div>
    
    <div>
      Nele  &#8211;  <strong>Kit Clayton</strong> &#8211;  <em>Nek Sanalet</em>
    </div>
    
    <div>
      Booc  &#8211;  <strong>Plaid</strong> &#8211;  <em>Booc</em>
    </div>
    
    <div>
      Bike  &#8211;  <strong>Autechre</strong> &#8211;  <em>Incunabula</em>
    </div>
    
    <div>
      On the Hook  &#8211;  <strong>Savvas Ysatis</strong> &#8211;  <em>Select</em>
    </div>
    
    <div>
      BBRobot (Senor Frio Remix)  &#8211;  <strong>Ion Driver</strong> &#8211;  <em>DDD033</em>
    </div>
    
    <div>
      I Wanna be Your STD  &#8211;  <strong>Jimmy Edgar</strong> &#8211;  <em>Warp20</em>
    </div>
    
    <div>
      Tweak Sauce  &#8211;  <strong>Tipper</strong> &#8211;  <em>Autonomous Addicts</em>
    </div>
    
    <div>
      Ulysses [<strong>Fax</strong> Mix]  &#8211;  <strong>Murcof</strong> &#8211;  <em>Utopia</em>
    </div>
    
    <div>
      he never showed up  &#8211;  <strong>Phil Western and Tim Hill</strong> &#8211;  <em>Dark Features</em>
    </div>
    
    <div>
      Moth  &#8211;  <strong>Burial & Four Tet</strong> &#8211;  <em>Moth / Wolf Cub</em>
    </div>
    
    <div>
      Alspacka  &#8211;  <strong>The Tuss</strong> &#8211;  <em>Confederation Trough EP</em>
    </div>
    
    <div>
      Jarvik Mindstate  &#8211;  <strong>Peverelist</strong> &#8211;  <em>Jarvik Mindstate</em>
    </div>
    
    <div>
      Sun Step  &#8211;  <strong>Oxia</strong> &#8211;  <em>Sun Step EP</em>
    </div>
    
    <div>
      Northern Wish  &#8211;  <strong>Artic Hospital</strong> &#8211;  <em>Terminal</em>
    </div>
    
    <div>
      Cornish Acid  &#8211;  <strong>Aphex Twin</strong> &#8211;  <em>Richard D. James Album</em>
    </div>
    
    <div>
      Whole Life  &#8211;  <strong>Oxia</strong> &#8211;  <em>Sun Step EP</em>
    </div>
    
    <div>
      Kamaco  &#8211;  <strong>Craque</strong> &#8211;  <em>Jawbone</em>
    </div>
    
    <div>
      Channel Two  &#8211;  <strong>2562</strong> &#8211;  <em>Round Black Ghosts</em>
    </div>
    
    <div>
      Moongomery  &#8211;  <strong>Ricardo Villalobos</strong> &#8211;  <em>Fabric 36 &#8211; Ricardo Villalobos</em>
    </div>
    
    <div>
      Memoria [<strong>Sutekh</strong>&#8216;s Trisagion Mix]  &#8211;  <strong>Murcof</strong> &#8211;  <em>Utopia</em>
    </div>
    
    <div>
      The Dragonfly Who Thought He Was a Mockingbird  &#8211;  <strong>Akufen</strong> &#8211;  <em>Appleseed Original Soundtrack</em>
    </div>
    
    <div>
      My Head Feels Like A Frisbee  &#8211;  <strong>Shpongle</strong> &#8211;  <em>Tales Of The Inexpressible</em>
    </div>
    
    <div>
      Epilepsia  &#8211;  <strong>Dinky</strong> &#8211;  <em>Anemik</em>
    </div>
    
    <div>
      I Love Acid  &#8211;  <strong>Luke Vibert</strong> &#8211;  <em>Warp20</em>
    </div>
    
    <div>
      My Red Hot Car  &#8211;  <strong>Squarepusher</strong> &#8211;  <em>Go Plastic</em>
    </div>
    
    <div>
      Uhm  &#8211;  <strong>Download</strong> &#8211;  <em>FiXeR</em>
    </div>
    
    <div>
      Into the Duster  &#8211;  <strong>Pantytec</strong> &#8211;  <em>Pony Slaystation</em>
    </div>
    
    <div>
      Pathfinder  &#8211;  <strong>Savvas Ysatis</strong> &#8211;  <em>Select</em>
    </div>
    
    <div>
      Glacial  &#8211;  <strong>Dinky</strong> &#8211;  <em>Anemik</em>
    </div>
  </div>
</div>