---
title: dave smith arpeggiator madness!
author: craque
type: post
date: 2012-01-23T00:11:03+00:00
url: /2012/01/22/dave-smith-arpeggiator-madness/
categories:
  - Uncategorized
format: image

---
[<img src="https://sounding.com/blog/wp-content/uploads/2012/01/20120122-161033.jpg" alt="20120122-161033.jpg" class="alignnone size-full" />][1]

 [1]: https://sounding.com/blog/wp-content/uploads/2012/01/20120122-161033.jpg