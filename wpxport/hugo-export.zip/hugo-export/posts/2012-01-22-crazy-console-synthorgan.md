---
title: crazy console synthorgan
author: craque
type: post
date: 2012-01-22T23:42:03+00:00
url: /2012/01/22/crazy-console-synthorgan/
categories:
  - Uncategorized
format: image

---
[<img src="https://sounding.com/blog/wp-content/uploads/2012/01/20120122-154138.jpg" alt="20120122-154138.jpg" class="alignnone size-full" />][1]

 [1]: https://sounding.com/blog/wp-content/uploads/2012/01/20120122-154138.jpg