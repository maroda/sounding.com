---
title: 'New Release: Material'
author: craque
type: post
date: 2008-07-09T22:12:20+00:00
url: /2008/07/09/new-release-material/
categories:
  - Craque
tags:
  - netlabels
  - releases

---
[<img class="alignleft size-thumbnail wp-image-95" title="Material" src="https://sounding.com/blog/wp-content/uploads/2008/07/material-150x150.jpg" alt="Material" hspace="5" width="150" height="150" srcset="https://sounding.com/blog/wp-content/uploads/2008/07/material-150x150.jpg 150w, https://sounding.com/blog/wp-content/uploads/2008/07/material-300x300.jpg 300w, https://sounding.com/blog/wp-content/uploads/2008/07/material.jpg 550w" sizes="(max-width: 150px) 100vw, 150px" />][1]Since this release came out while my blog was unavailable, thought I would shout it out that a new Craque album called <a title="Material" href="http://www.kahvi.org/releases.php?release_number=249" target="_blank">Material</a> is available on Kahvi Collective! From the website:

> &#8220;Guest artist craque arrives on Kahvi Collective with a unique blend of textures and IDM elements. Five track &#8216;Material&#8217; verges on the style of &#8216;MigloJE&#8217;. Torus Europa sets the scene with its lush, drawn out passages of sound and textures and leads into the interesting &#8216;strawberry jam&#8217;, an atonal melody drawing on a paced bass line which makes a nice combination and the extraordinary &#8216;organum&#8217; (my personal favourite of this release) with &#8216;that&#8217; sample hook that fits so well with the rest of the track. a great first release from craque, perhaps we\`ll see more from him in the future?&#8221;

I think probably so there will be more Craque appearing at Kahvi, and hopefully others real soon!

 [1]: https://sounding.com/blog/wp-content/uploads/2008/07/material.jpg