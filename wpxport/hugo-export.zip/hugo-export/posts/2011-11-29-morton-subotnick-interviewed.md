---
title: Morton Subotnick Interviewed
author: craque
type: post
date: 2011-11-30T01:08:05+00:00
url: /2011/11/29/morton-subotnick-interviewed/
categories:
  - creativity
  - External
  - listening
  - Music Tech
tags:
  - composition
  - electronics
  - synths

---
This is a great interview of an awesome figure in electronic music, done just recently (2011) in Madrid by the [Red Bull Music Academy][1]:

<!-- iframe plugin v.4.4 wordpress.org/plugins/iframe/ -->

_Listen to a free stream of <a href="http://www.last.fm/music/Morton+Subotnick/The+Silver+Apples+Of+The+Moon" title="Silver Apples of the Moon" target="_blank">Silver Apples of the Moon</a> on last.fm._

 [1]: http://vimeo.com/redbullmusicacademy