---
title: Ubuweb posts Greenaway’s 4 American Composers
author: craque
type: post
date: 2011-12-08T16:40:26+00:00
url: /2011/12/08/ubuweb-posts-greenaways-4-american-composers/
categories:
  - creativity
  - External
  - performance
tags:
  - documentary
  - john cage
  - meredith monk
  - philip glass
  - robert ashley

---
Back in the mid 90&#8217;s before I ever got into techno music, I owned the original VHS copy of Peter Greenaway&#8217;s 1983 release <a href="http://www.imdb.com/title/tt0085562/" target="_blank"><strong>4merican Composers</strong></a> (natch, &#8220;Four American Composers&#8221;) and watched it constantly while in music school; I think I probably saw the Cage movie no less than 10 times.

As a honorable musicologist is want to do, I lent my copy out to a friend who had never heard of any of them, but then never got it back because of moving across the country. So I&#8217;ve been searching high and low for higher quality versions of these videos.

It is way out of print, but you can still find the VHS version&#8230; they&#8217;ve been released on DVD in Europe, but only in PAL format. In the digital age, this is unacceptable for me, so I finally came across someone who ripped the videos and I now have &#8211; albeit in relatively lowres VHS-sourced AVI files &#8211; all four on my iPod. The quality is what you&#8217;d expect from a 30-year old VHS tape, but it&#8217;s not horrible.

I&#8217;ve been struggling about whether to post them myself, but today Ubuweb has answered my prayers and posted all of them for me (lo and behold, the quality is no better than my collected AVI files, I suspect they may have procured them from the same source).

So here they are, I highly recommend&#8230; they are the greatest films about avant garde music you&#8217;ll ever find anywhere:  


  


  * <a href="http://www.ubu.com/film/greenaway_cage.html" target="_blank">4merican Composers: John Cage</a>  
      * <a href="http://www.ubu.com/film/greenaway_glass.html" target="_blank">4merican Composers: Philip Glass</a>  
          * <a href="http://www.ubu.com/film/greenaway_monk.html" target="_blank">4merican Composers: Meredith Monk</a>  
              * <a href="http://www.ubu.com/film/greenaway_ashley.html" target="_blank">4merican Composers: Robert Ashley</a>  
                </UL></p>