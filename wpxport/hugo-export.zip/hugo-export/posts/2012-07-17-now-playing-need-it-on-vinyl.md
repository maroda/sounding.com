---
title: 'Now Playing: Need it on Vinyl!'
author: craque
type: post
date: 2012-07-17T14:34:06+00:00
url: /2012/07/17/now-playing-need-it-on-vinyl/
categories:
  - listening
tags:
  - now playing

---
&#8211; SCSI-9 ::: _Metamorphosis_ &#8211;

&#8211; Extrawelt ::: _In Aufruhr_ &#8211;

&#8211; Cristian Vogel ::: _The Inertials_ &#8211;

&#8211; Forward Strategy Group ::: _Labour Division_ &#8211;