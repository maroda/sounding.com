---
title: Soaking Tide
author: craque
type: post
date: 2008-07-14T07:55:57+00:00
url: /2008/07/14/soaking-tide/
categories:
  - Uncategorized

---
One of my favorite pastimes recently is surfing through social sites like <a title="craque @ last.fm" href="http://www.last.fm/user/craque/" target="_blank">last.fm</a>, following neighbor and friend links to different people&#8217;s pages and friends and neighbors and so on and so on&#8230; it&#8217;s a fascinating and sometimes recursive journey through the tastes of like minded individuals.