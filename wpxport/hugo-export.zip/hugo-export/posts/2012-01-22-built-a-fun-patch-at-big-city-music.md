---
title: built a fun patch at big city music
author: craque
type: post
date: 2012-01-22T23:43:06+00:00
url: /2012/01/22/built-a-fun-patch-at-big-city-music/
categories:
  - Uncategorized
format: image

---
[<img src="https://sounding.com/blog/wp-content/uploads/2012/01/20120122-154230.jpg" alt="20120122-154230.jpg" class="alignnone size-full" />][1]

 [1]: https://sounding.com/blog/wp-content/uploads/2012/01/20120122-154230.jpg