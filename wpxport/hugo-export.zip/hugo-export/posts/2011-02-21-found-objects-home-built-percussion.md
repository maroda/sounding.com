---
title: 'found objects: home-built percussion'
author: craque
type: post
date: 2011-02-21T18:42:16+00:00
url: /2011/02/21/found-objects-home-built-percussion/
categories:
  - Uncategorized

---
I like this <a href="http://rodrigoconstanzo.com/Instruments.html" target="_blank">collection of DIY and lo-fi instruments</a> that Rodrigo Constantzo has built, modded and incorporated into his percussion setup. Some great descriptions and ideas!