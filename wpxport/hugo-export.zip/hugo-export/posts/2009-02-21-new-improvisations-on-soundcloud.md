---
title: New improvisations on SoundCloud
author: craque
type: post
date: 2009-02-21T19:10:57+00:00
url: /2009/02/21/new-improvisations-on-soundcloud/
categories:
  - Craque
  - listening
  - Music Tech
tags:
  - glitch
  - improvisation
  - microsound

---
Freely improvised one-takes. Instrumentation includes homebuilt instruments, sampled objects and looping hardware.

<div style="font-size: 11px;">
</div>

This music sharing site is a great tool for posting various non-published tracks, as well as released stuff, and has a nice embeddable player and comment system. Really nice for being able to just slap some stuff up, I have one friend who has recently been doing the same with sessions on his new Serge Modular Creature, and another who posted &#8220;in progress&#8221; snapshots of a track he is working on.

Feel free to download and remix, just give the proper attribution. 🙂