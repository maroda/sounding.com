---
title: 'Now Playing: New-to-me Edition'
author: craque
type: post
date: 2012-04-23T16:43:23+00:00
url: /2012/04/23/now-playing-new-to-me-edition/
categories:
  - listening
tags:
  - now playing

---
&#8211; Orbital ::: _In Sides_ &#8211;  
&#8211; Dalglish ::: _Benacah Drann Deachd_ &#8211;  
&#8211; Aus ::: _Lang_ &#8211;  
&#8211; Tycho ::: _The Science of Patterns_ &#8211;  
&#8211; Various Artists ::: _Elektronische Musik &#8211; Interkontinental_ &#8211;