---
title: Now Playing
author: craque
type: post
date: 2012-02-17T15:55:29+00:00
url: /2012/02/17/now-playing/
categories:
  - listening
tags:
  - playlists

---
&#8211; Lackluster ::: _The Invisible Spanish Inquisition_ &#8211;

&#8211; Steve Martin & The Steep Canyon Rangers ::: _Rare Bird Alert &#8211;_

&#8211; Marcus Fischer ::: _Collected Dust &#8211;_

&#8211; Woob ::: _Paradigm Flux &#8211;_

&#8211; Stimming ::: _Cheesecake &#8211;_