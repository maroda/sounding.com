---
title: Brian Eno’s 77 million and the Mac
author: craque
type: post
date: 2007-06-21T18:15:00+00:00
url: /2007/06/21/brian-enos-77-million-and-the-mac/
wpo_campaignid:
  - 1
wpo_feedid:
  - 1
wpo_sourcepermalink:
  - https://sounding.com/bin/view/Sounding/BlogEntry4
categories:
  - TWiki Archive

---
If you&#8217;re in San Fran, do not miss the North American premiere of Brian Eno&#8217;s <a target="_blank" href="http://www.77millionpaintings.com/">77 Million Paintings</a> exhibit at the <a target="_blank" href="http://www.ybca.org/">Yerba Buena Center for the Arts</a> the weekend of June 29th. </p> 

This looks like a fantastic thing, what&#8217;s even cooler is that it&#8217;s <a target="_blank" href="http://blog.wired.com/monkeybites/2007/06/an_army_of_macs.html">all done with Macs!</a> </p> 

You can also buy the work on DVD, but obviously it was meant for a grand space. Details of the event are on the <a target="_blank" href="http://www.longnow.org/77m/">Long Now Foundation website.</a></p> 

**Tags**: <a href="https://sounding.com/bin/view/Sounding/BlogArchive?mode=tag&search=installations, video" rel="tag">installations, video</a></p>