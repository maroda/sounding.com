---
title: Now Playing
author: craque
type: post
date: 2012-03-14T22:19:57+00:00
url: /2012/03/14/now-playing-2/
categories:
  - listening
tags:
  - now playing

---
&#8211; Farben ::: _Farben EP_ &#8211;

&#8211; Burnt Friedman ::: _Bokoboko_ &#8211;

&#8211; Susumu Yokota ::: _Dreamer_ &#8211;

&#8211; John Tejada & Justin Maxwell ::: _Patch Adams / Thundaar the Modularian_ &#8211;

&#8211; Dalglish ::: _Benacah Drann Deachd_ &#8211;

&nbsp;