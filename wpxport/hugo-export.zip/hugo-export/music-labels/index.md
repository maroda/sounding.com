---
title: Music Labels
author: admin
type: page
date: 2008-07-06T20:03:26+00:00
draft: true
private: true

---
[sonicSQUIRREL][1] is a sort of netlabel compendium. Great resource!

A few notables&#8230;

  * [12k/L-NE][2]
  * [Audiobulb][3]
  * [Constanta][4]
  * <a href="http://erotus.net/" target="_blank" rel="noopener noreferrer">Erotus</a>
  * [Kahvi][5]
  * [Kikapu][6]
  * <a href="http://merckrecords.com/" target="_blank" rel="noopener noreferrer">Merck</a>
  * <a href="http://www.pertin-nce.com/" target="_blank" rel="noopener noreferrer">Pertin_nce</a>
  * [Somnia][7]
  * [Stadtgruen][8]
  * [Test Tube][9]
  * <a href="http://www.tzadik.com/" target="_blank" rel="noopener noreferrer">Tzadik</a>
  * [Xynthetic][10]
  * [Zymogen][11]

Some other online labels I&#8217;ve come across that have been interesting in one way or another&#8230;

 [1]: http://sonicsquirrel.net/
 [2]: http://12k.com
 [3]: http://audiobulb.com
 [4]: http://constanta-label.ru/
 [5]: http://www.kahvi.org/
 [6]: http://www.kikapu.com
 [7]: http://www.nativestaterecords.com/somnia/releases.htm
 [8]: http://stadtgruenlabel.net
 [9]: http://www.monocromatica.com/netlabel/
 [10]: http://www.xynthetic.com/
 [11]: http://zymogen.net